// DM2008
// Activity 1b (Ryoji Ikeda)

let x;
let w;

function setup() {
  createCanvas(800, 800);
  background(255);
  noStroke();
}

function draw() {
  background(255, 10);
  fill(0, 0, 0);
  x = random(width);
  w = random(1, 20);
  rect(x, 0, w, height / 2);

  x = random(width);
  rect(x, height / 2, w, height / 3);

  noFill();
  stroke(0, 0, 0);
  strokeWeight(50);
  circle(width / 2, height / 2, w * 100);

  fill(255, 0, 0);
  noStroke();
  rect(0, mouseY, width, random(1 - 20));
}

function keyPressed() {
  saveCanvas("activity1b-image", "jpg");
}
