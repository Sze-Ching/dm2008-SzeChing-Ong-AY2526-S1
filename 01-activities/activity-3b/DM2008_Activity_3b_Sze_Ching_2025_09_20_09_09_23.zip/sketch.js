// DM2008 — Activity 3b
// (One Function Wonder, 15 min)
let img_mat, img_grass;

function preload() {
  img_mat = loadImage("assets/checkers.jpg");
  img_grass = loadImage("assets/grass.jpg");
}

function setup() {
  createCanvas(400, 400);
  rectMode(CENTER);
}

function draw() {
  background(0, 0, 0);

  image(img_grass, 0, 0);
  image(img_mat, 0, 0);

  // TODO 1:
  // Define a function that draws something (a shape or group of shapes).
  // It should take at least one parameter (e.g., position, size, or color).

  // TODO 2:
  // Call your function multiple times with different parameter values.
  drawShape(100, 200, 80);
  drawShape(200, 30, 200);

  drawShape(mouseX, mouseY, 120);

  // TODO 3:
  // (Challenge) Call your function inside a for loop
  // to create a repeating pattern or variation.
}

// Example starter function:
function drawShape(x, y, size) {
  //meat
  fill("#9B4B00");
  ellipse(x, y, size, size);
  noStroke();

  //cheese
  fill("#FFE700");
  rect(x, y, size / 1.2, size / 1.2);

  //top bun
  fill("#FFA600");
  ellipse(x, y, size / 1.15, size / 1.15);
}

function keyPressed() {
  saveCanvas("activity3b-image", "jpg");
}