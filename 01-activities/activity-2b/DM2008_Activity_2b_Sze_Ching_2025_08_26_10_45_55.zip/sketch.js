// DDM2008 — Activity 2b
// (Pattern Making, 40 min)
let s = 100; //amt of times shape is drawn
let x = 0; // ellipse x-position
let t = 2;
let bgColor; // background color set by switch(key)
let size = 5;

function setup() {
  createCanvas(400, 400);
  bgColor = color(225);
}

function draw() {
  background(bgColor);
s = map(mouseY, 0, width, 20, 100);
  
  // A simple horizontal row of shapes using a 1D loop
  for (let i = 0; i < 10; i++) {
    for (let j = 0; j < 10; j++) {
      // TODO: replace ellipse with your own pattern
      ellipse(x,i * 100, j * 100, s);

      fill(0, 100, 255);
      stroke("#FFFFFF");
      strokeWeight(8);
      }
    }
  
   x += t; //speed of ellipse
      // Wrap around when it exits the right edge
      if (x > width + size / 2) {
        x = 0;
      
  }

  // TODO: add an if() condition to alternate shape, size, or color
  // (hint: use % modulo to alternate every other shape)
}

function keyPressed() {
  switch (key) {
    case "1":
      bgColor = color("#FFB5B5");
      t = 5;
      break;

    case "2":
      bgColor = color("#80FF8A");
      t = 5;
      break;

    case "3":
      bgColor = color("#FFA600");
      t = 5;
      break;

    default:
      bgColor = color(225);
      t = 5;
  }
}
// TODO: add one interaction (mouse or key) to change the rule
// (hint: try changing fill() or size when mouseIsPressed)

function mousePressed() {
  saveCanvas("activity2b-image", "jpg");
}
