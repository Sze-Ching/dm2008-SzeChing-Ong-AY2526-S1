// DDM2008
// Activity 1a

// Run the sketch, then click on the preview to enable keyboard
// Use the 'Option' ('Alt' on Windows) key to view or hide the grid
// Use the 'Shift' key to change overlays between black & white
// Write the code for your creature in the space provided

function setup() {
  createCanvas(400, 400);
}

function draw() {
  background(255, 200, 200);

  // YOUR CODE HERE

  //face
  fill(0, 0, 0);
  noStroke();
  circle(200, 200, 50);

  //left ear
  fill(0, 0, 0);
  triangle(175, 145, 178, 200, 200, 200);

  //right ear
  fill(0, 0, 0);
  triangle(200, 145, 203, 200, 200 + (200 - 178), 200);

  //body
  ellipse(200, 250, 50, 70);

  //nose
  fill("#CAA0CE");
  triangle(205, 200, 212, 200, 210, 205);

  //ribbon
  fill("#C50000");
  triangle(210, 223, 195, 213, 195, 236);
  triangle(210, 223, 225, 213, 225, 236);
  ellipse(210, 223, 8);

  //eyes
  fill(255, 255, 255);
  ellipse(196, 196, 15);
  ellipse(219, 196, 15);

  //pupils
  fill(0, 0, 0);
  ellipse(198, 196, 4, 10);
  ellipse(221, 196, 4, 10);

  //tail
  stroke(0, 0, 0);
  noFill();
  strokeWeight(10);
  arc(198, 230, 100, 100, HALF_PI, PI);

  //broomstick
  stroke("#C06D00");
  strokeWeight(10);
  line(250, 280, 60, 290);

  //broombristles
  noStroke();
  fill("#FFBB00");
  ellipse(115, 286, 40, 30);
  fill("#FFBB00");
  ellipse(75, 286, 70, 50);

  //broom ribbon
  noFill();
  stroke("#C50000");
  strokeWeight(6);
  line(104, 274, 104, 298);

  stroke("#FF9000");
  strokeWeight(3);
  line(45, 275, 64, 275);
  line(44, 287, 70, 287);
  line(47, 300, 64, 300);

  // YOUR CODE HERE

  helperGrid(); // do not edit or remove this line
}
