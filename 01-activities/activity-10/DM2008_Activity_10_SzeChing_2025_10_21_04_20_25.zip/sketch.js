let colorBtn, bgBtn, sizeSlider, shapeSelect;
let shapeColor, bgColor;
let pulseSize = 0; 

function setup() {
  createCanvas(640, 400);
  textFont("Helvetica, Arial, sans-serif");

  shapeColor = color(random(255), random(255), random(255));
  bgColor = color(random(255), random(255), random(255));

  colorBtn = createButton("Change Shape Color");
  colorBtn.position(16, 16);
  colorBtn.mousePressed(() => {
    shapeColor = color(random(255), random(255), random(255));
    
  });

  bgBtn = createButton("Change Background Color");
  bgBtn.position(16, 50);
  bgBtn.mousePressed(() => {
    bgColor = color(random(255), random(255), random(255));
    
  });

  createP("Size").position(0, 80).style("margin", "4px 0 0 16px");
  sizeSlider = createSlider(20, 220, 100, 1);
  sizeSlider.position(15, 100);

  createP("Shape").position(0, 120).style("margin", "8px 0 0 16px");
  shapeSelect = createSelect();
  shapeSelect.position(16, 150);
  shapeSelect.option("ellipse");
  shapeSelect.option("rect");
  shapeSelect.option("triangle");

  createP("Click anywhere to pulse!").position(width/2,height/5).style("margin", "8px 0 0 16px");
}

function draw() {
  background(bgColor);
  translate(width * 0.65, height * 0.5);

  // reduce pulse gradually
  if (pulseSize > 0) {
    pulseSize *= 0.9; // fading speed
  }

  let s = sizeSlider.value() + pulseSize;

  fill(shapeColor);
  noStroke();

  let choice = shapeSelect.value();
  if (choice === "ellipse") {
    ellipse(0, 0, s, s);
  } else if (choice === "rect") {
    rectMode(CENTER);
    rect(0, 0, s, s);
  } else if (choice === "triangle") {
    triangle(-s * 0.6, s * 0.5, 0, -s * 0.6, s * 0.6, s * 0.5);
  }
}

function mousePressed() {
  pulseSize = 100; 
}

