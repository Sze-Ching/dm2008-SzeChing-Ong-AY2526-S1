// DDM2008 — Activity 2a
// (Mode Switch, 20 min)

let x = 0; // ellipse x-position
let size = 50; // ellipse size (you can change this in your if/else)
let bgColor; // background color set by switch(key)
let t = 5;

function setup() {
  createCanvas(400, 400);
  bgColor = color(220);
}

function draw() {
  background(bgColor);

  fill(0,0,255);
  strokeWeight(10)
  ellipse(x, height / 2, size);

  x += t; //speed of ellipse
  // Wrap around when it exits the right edge
  if (x > width + size / 2) {
    x = 0;
  }
}

// --- Mode switching with number keys: 1, 2, 3 ---
function keyPressed() {
  switch (key) {
    case "1":
      bgColor = color(200, 100, 100); // red
      t = 30;
      size = 70;
      break;
      
    case "2":
      bgColor = color(100, 200, 100); // green
      t = 10;
      size = 40;
      break;
      
    case "3":
      bgColor = color(100, 100, 200); // blue
      t = 1;
      size = 80;
      break;
      
    default:
      bgColor = color(220); // grey
      t = 5;
  }
}

function mousePressed() {
  saveCanvas("activity2a-image", "jpg");
}
